from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User, Group
from django.contrib.auth import login
from django.http import HttpResponse
from .models import Estudiante

# Create your views here.
def metodoLogin(request):
    return render(request, 'Login.html')

def metodoMenuSuperUsuario(request):
    return render(request, 'Menu_superUsuario.html')

def metodoRegistroEstudiante(request):
    if request.method == 'GET':
        return render(request, 'registrarEstudiante.html', {
        'form': UserCreationForm
        })
    else:
        auxMatricula = request.POST.get('username') #obtener la matricula del forms
        if Estudiante.objects.filter(matricula=auxMatricula).exists(): #verificar que la matricula existe
            if request.POST['password1'] == request.POST['password2']:  # Si las contraseñas son iguales
                try:
                    # Crear objeto usuario
                    user = User.objects.create_user(username=auxMatricula, password=request.POST['password1'])
                    # Guardar en la base de datos
                    user.save()
                     # Obtener el grupo de estudiantes (ID = 1)
                    estudiante_group = Group.objects.get(id=1)
                    # Asignar el usuario al grupo de estudiantes
                    user.groups.add(estudiante_group)
                    login(request, user) #cookies... me van a guardar datos 

                    return HttpResponse("Estudiante dado de alta correctamente")
                except:
                    return render(request, 'registrarEstudiante.html', {
                        'form': UserCreationForm(),
                        "error": "El usuario ya existe"
                    })
            else:
                return render(request, 'registrarEstudiante.html', {
                    'form': UserCreationForm(),
                    "error": "Las contraseñas no coinciden"
                })
        else:
            return render(request, 'registrarEstudiante.html', {
                'form': UserCreationForm(),
                "error": "La matrícula no existe"
            })    