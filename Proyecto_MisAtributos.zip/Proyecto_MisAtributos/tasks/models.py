from django.db import models
from datetime import date

class datosPersonales(models.Model):
    curp = models.CharField(primary_key=True, max_length=100)
    nombres = models.CharField(max_length=50)
    apellidoP = models.CharField(max_length=50)
    apellidoM = models.CharField(max_length=50)
    fecha_nacimiento = models.DateField()
    correo = models.EmailField(max_length=254)
    telefono = models.CharField(max_length=50)

class programaEducativo(models.Model):
    idPrograma = models.IntegerField(primary_key=True)
    nombrePrograma = models.CharField(max_length=50)
    status = models.BooleanField(default=True)


class Estudiante(models.Model):
    R_datosPer = models.ForeignKey(datosPersonales, on_delete=models.CASCADE)
    R_programa = models.ForeignKey(programaEducativo, on_delete=models.CASCADE)
    matricula = models.CharField(primary_key=True, max_length=100)
    calificacion_admision = models.FloatField(default=True)

class Profesor(models.Model):
    R_datosPer = models.ForeignKey(datosPersonales, on_delete=models.CASCADE)
    matricula = models.CharField(primary_key=True, max_length=100)

    