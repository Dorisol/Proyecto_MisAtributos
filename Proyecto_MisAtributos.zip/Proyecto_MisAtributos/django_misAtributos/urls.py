
from django.contrib import admin
from django.urls import path
from tasks import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.metodoLogin, name="home"), #raiz
    path('registroEst/', views.metodoRegistroEstudiante, name="registro_est_url"),
    path('menuSuperUsuario/', views.metodoMenuSuperUsuario, name="menu_superusuario_url"),
]
